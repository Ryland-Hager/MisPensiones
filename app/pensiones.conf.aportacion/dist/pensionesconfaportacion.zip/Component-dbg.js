sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("pensiones.conf.aportacion.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);