sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("pensiones.conf.cat.der.adquiridos.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);