sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("pensiones.conf.pe.carta.rec.kee.aux3.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);